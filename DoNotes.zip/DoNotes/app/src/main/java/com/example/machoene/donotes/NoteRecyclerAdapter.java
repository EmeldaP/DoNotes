package com.example.machoene.donotes;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

/**
 * Created by machoene on 2019-07-24.
 */

public class NoteRecyclerAdapter extends RecyclerView.Adapter<NoteRecyclerAdapter.ViewHolder>{

    private final List<NoteInfo> mNotes;
    private final Context mContext;
    private final LayoutInflater mLayoutInflater;

    public NoteRecyclerAdapter(Context context,  List<NoteInfo> mNotes) {
        this.mNotes = mNotes;

        mContext = context;

        mLayoutInflater = LayoutInflater.from(mContext);

    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        //
       View itemV = mLayoutInflater.inflate(R.layout.list_note,parent,false);
        return new ViewHolder(itemV);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        NoteInfo note = mNotes.get(position);
        holder.mTextCourse.setText(note.getCourse().getTitle());
        holder.mTextTitle.setText(note.getTitle());
        holder.mCurrentPosition = position;


    }

    @Override
    public int getItemCount() {
        return mNotes.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder{

        public final TextView mTextCourse;
        public final TextView mTextTitle;
        public  int mCurrentPosition;

        public ViewHolder(View itemView) {
            super(itemView);
            //ref for text in list note
            mTextCourse = (TextView)itemView.findViewById(R.id.text_course);
            mTextTitle = (TextView)itemView.findViewById(R.id.text_title);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(mContext,NoteActivity.class);
                    intent.putExtra(NoteActivity.NOTE_POSITION,mCurrentPosition);
                    mContext.startActivity(intent);
                }
            });
        }
    }

}
